package catHouse.entities.toys.interfaces;

public interface Toy {
    int getSoftness();

    double getPrice();
}
