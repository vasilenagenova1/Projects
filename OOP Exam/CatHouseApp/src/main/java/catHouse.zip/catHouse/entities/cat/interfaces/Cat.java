package catHouse.entities.cat.interfaces;

public interface Cat {
    String getName();

    void setName(String name);

    int getKilograms();

    double getPrice();

    void eating();
}
